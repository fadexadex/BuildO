"use client";

import { Canvas } from "@react-three/fiber";
import { OrbitControls, Stars, Float } from "@react-three/drei";
import { useGameState } from "@/hooks/use-game-state";
import { DemoModeProvider } from "@/hooks/use-demo-mode";
import { WorldMap } from "./WorldMap";
import { DemoControlPanel } from "./DemoControls";
import { AchievementGallery } from "./AchievementGallery";
import { Leaderboard } from "./Leaderboard";
import { LoadingAnimation } from "./3d/LoadingAnimation";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Trophy, Star, Zap, Settings } from "lucide-react";
import { Suspense, useState, useEffect } from "react";
import { PerformanceStats } from "@/lib/performance";

function AnimatedBackground() {
  return (
    <>
      <Stars
        radius={100}
        depth={50}
        count={5000}
        factor={4}
        saturation={0}
        fade
        speed={1}
      />
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
    </>
  );
}

function LoadingFallback() {
  return (
    <div className="flex items-center justify-center h-full">
      <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
        <LoadingAnimation message="Loading 3D Scene..." type="default" />
      </Canvas>
    </div>
  );
}

export function GameShell() {
  const { gameState, isLoading, resetGameState } = useGameState();
  const [showAchievements, setShowAchievements] = useState(false);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [showPerformanceStats, setShowPerformanceStats] = useState(false);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      // Ctrl/Cmd + P = Toggle performance stats
      if ((e.ctrlKey || e.metaKey) && e.key === "p") {
        e.preventDefault();
        setShowPerformanceStats((prev) => !prev);
      }
      // Ctrl/Cmd + A = Open achievements
      if ((e.ctrlKey || e.metaKey) && e.key === "a") {
        e.preventDefault();
        setShowAchievements((prev) => !prev);
      }
    };

    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, []);

  if (isLoading || !gameState) {
    return (
      <div className="flex items-center justify-center h-screen bg-gradient-to-b from-slate-950 to-slate-900">
        <div className="text-white text-2xl">Loading ZK Quest...</div>
      </div>
    );
  }

  const xpProgress = (gameState.xp % 500) / 5; // Calculate percentage for current level
  const completionPercentage = (gameState.completedLevels.length / 9) * 100;

  return (
    <DemoModeProvider>
      <div className="relative h-screen w-full overflow-hidden bg-slate-950">
      {/* 3D Background */}
      <div className="absolute inset-0 z-0">
        <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
          <Suspense fallback={null}>
            <AnimatedBackground />
            <OrbitControls
              enableZoom={false}
              enablePan={false}
              autoRotate
              autoRotateSpeed={0.5}
            />
          </Suspense>
        </Canvas>
      </div>

      {/* Game UI Overlay */}
      <div className="relative z-10 h-full flex flex-col">
        {/* Header */}
        <header className="bg-slate-900/80 backdrop-blur-md border-b border-slate-700">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              {/* Logo and Title */}
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Zap className="w-8 h-8 text-cyan-400" />
                  <div className="absolute inset-0 blur-xl bg-cyan-400/50" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white">ZK Quest</h1>
                  <p className="text-sm text-slate-400">
                    Zero-Knowledge Proof Playground
                  </p>
                </div>
              </div>

              {/* Player Stats */}
              <div className="flex items-center gap-6">
                {/* XP and Level */}
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-xs text-slate-400">Level</div>
                    <div className="text-lg font-bold text-white">
                      {gameState.level}
                    </div>
                  </div>
                  <div className="w-48">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-slate-400">XP</span>
                      <span className="text-xs text-slate-300">
                        {gameState.xp % 500}/500
                      </span>
                    </div>
                    <Progress value={xpProgress} className="h-2" />
                  </div>
                </div>

                {/* Achievements */}
                <Button
                  variant="ghost"
                  className="flex items-center gap-2 hover:bg-yellow-500/20"
                  onClick={() => setShowAchievements(true)}
                >
                  <Trophy className="w-5 h-5 text-yellow-500" />
                  <span className="text-white font-semibold">
                    {gameState.achievements.length}
                  </span>
                </Button>

                {/* Leaderboard */}
                <Button
                  variant="ghost"
                  className="flex items-center gap-2 hover:bg-blue-500/20"
                  onClick={() => setShowLeaderboard(true)}
                >
                  <Star className="w-5 h-5 text-blue-400" />
                  <span className="text-white font-semibold">Leaderboard</span>
                </Button>

                {/* Completion */}
                <Badge variant="secondary" className="gap-2">
                  <Star className="w-4 h-4" />
                  {gameState.completedLevels.length}/9 Levels
                </Badge>

                {/* Settings */}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    if (
                      confirm("Reset game progress? This cannot be undone.")
                    ) {
                      resetGameState();
                    }
                  }}
                >
                  <Settings className="w-5 h-5" />
                </Button>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mt-4">
              <Progress value={completionPercentage} className="h-1" />
            </div>
          </div>
        </header>

        {/* Main Content - World Map */}
        <main className="flex-1 overflow-auto">
          <WorldMap />
        </main>

        {/* Footer */}
        <footer className="bg-slate-900/80 backdrop-blur-md border-t border-slate-700 py-3">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between text-sm text-slate-400">
              <div>
                Player: <span className="text-white">{gameState.playerName}</span>
              </div>
                {gameState.hederaAccountId && (
                <div>
                  Hedera: <span className="text-cyan-400">{gameState.hederaAccountId}</span>
                </div>
              )}
              <div>
                Made with ❤️ for Hedera Hackathon
              </div>
            </div>
          </div>
        </footer>
      </div>

      {/* Performance Stats (toggle with Ctrl+P) */}
      {showPerformanceStats && <PerformanceStats />}

      {/* Demo Control Panel */}
      <DemoControlPanel />

      {/* Achievement Gallery Modal */}
      {showAchievements && (
        <AchievementGallery onClose={() => setShowAchievements(false)} />
      )}

      {/* Leaderboard Modal */}
      {showLeaderboard && (
        <Leaderboard onClose={() => setShowLeaderboard(false)} />
      )}
    </div>
    </DemoModeProvider>
  );
}